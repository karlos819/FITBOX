//
//  FITBOXTests.swift
//  FITBOXTests
//
//  Created by 방문사용자 on 6/16/25.
//

import Testing
@testable import FITBOX

struct FITBOXTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
