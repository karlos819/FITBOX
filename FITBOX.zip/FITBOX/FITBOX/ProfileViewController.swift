import UIKit

class ProfileViewController: UIViewController {

    // MARK: - 아웃렛 연결
    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var weightTextField: UITextField!
    @IBOutlet weak var calorieTextField: UITextField!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var saveButton: UIButton!

    // MARK: - 초기화
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTextFields()
        setupButtons()
    }

    // MARK: - 텍스트필드 초기 설정
    func setupTextFields() {
        heightTextField.keyboardType = .numberPad
        weightTextField.keyboardType = .numberPad
        calorieTextField.keyboardType = .numberPad

        heightTextField.placeholder = "신장을 입력하세요 (cm)"
        weightTextField.placeholder = "체중을 입력하세요 (kg)"
        calorieTextField.placeholder = "적정 칼로리를 입력하세요 (kcal)"
    }

    // MARK: - 버튼 스타일 설정
    func setupButtons() {
        backButton.setTitle("←", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)

        saveButton.setTitle("저장", for: .normal)
        saveButton.setTitleColor(.white, for: .normal)
        saveButton.backgroundColor = .systemGreen
        saveButton.layer.cornerRadius = 8
    }

    // MARK: - 홈화면으로 돌아가기
    @IBAction func backToHome(_ sender: UIButton) {
        if let navigationController = self.navigationController {
            navigationController.popViewController(animated: true)
        } else {
            self.dismiss(animated: true, completion: nil)
        }
    }

    // MARK: - 저장 버튼 동작
    @IBAction func saveButtonTapped(_ sender: UIButton) {
        guard let height = heightTextField.text, !height.isEmpty,
              let weight = weightTextField.text, !weight.isEmpty,
              let calorie = calorieTextField.text, !calorie.isEmpty else {
            showAlert(message: "모든 항목을 입력해주세요.")
            return
        }

        // 실제 저장 로직은 여기에 추가
        print("신장: \(height), 체중: \(weight), 칼로리: \(calorie) kcal")
        showAlert(message: "저장되었습니다!")
    }

    // MARK: - 알림 표시
    func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "확인", style: .default))
        present(alert, animated: true)
    }
}
