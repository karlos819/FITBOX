import UIKit

class CalendarViewController: UIViewController {

    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var backButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        setupDatePicker()
        setupBackButton()
    }

    func setupDatePicker() {
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .inline  // iOS 14+에서 달력 스타일
        datePicker.tintColor = .systemGreen
    }

    func setupBackButton() {
        backButton.setTitle("←", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)
    }

    @IBAction func backToHomeTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
        // 또는 navigationController?.popViewController(animated: true)
    }
}

