import UIKit
import YouTubeiOSPlayerHelper
import HealthKit

class ExerciseViewController: UIViewController {
    
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var heartRateLabel: UILabel!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var prevButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var homeButton: UIButton!
    @IBOutlet weak var playerView: YTPlayerView!
    
    var timer: Timer?
    var secondsElapsed = 0
    var isPlaying = true
    var currentHeartRate = 0
    
    var videoIds: [String] = []
    var currentIndex = 0
    var isVideoLoaded = false
    
    let searchService = YouTubeSearchService(apiKey: "AIzaSyClanahAsAuOdc5bw_UJ59u7TTtmRfQlNw")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        startTimer()
    }
    
    func setupUI() {
        timerLabel.text = "00:00"
        heartRateLabel.text = "❤️ 심발수: 0 bpm"
        pauseButton.setTitle("⏸", for: .normal)
        prevButton.setTitle("⏮", for: .normal)
        nextButton.setTitle("⏭", for: .normal)
        homeButton.setTitle("홈으로", for: .normal)
    }
    
    func startTimer() {
        secondsElapsed = 0
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            self.secondsElapsed += 1
            let minutes = self.secondsElapsed / 60
            let seconds = self.secondsElapsed % 60
            self.timerLabel.text = String(format: "%02d:%02d", minutes, seconds)
            
            let heartRate = Int.random(in: 70...130)
            self.currentHeartRate = heartRate
            self.heartRateLabel.text = "❤️ 심박수: \(heartRate) bpm"
            
            if !self.isVideoLoaded {
                self.isVideoLoaded = true
                self.loadVideoForHeartRate(heartRate)
            }
        }
    }
    
    func loadVideoForHeartRate(_ heartRate: Int) {
        let query = "\(heartRate) bpm workout music"
        print("🔍 검색어: \(query)")
        
        searchService.search(query: query) { videoIDs in
            DispatchQueue.main.async {
                guard !videoIDs.isEmpty else {
                    print("❌ 검색 결과 없음")
                    return
                }
                self.videoIds = videoIDs
                self.currentIndex = 0
                self.loadCurrentVideo()
            }
        }
    }
    
    func loadCurrentVideo() {
        guard !videoIds.isEmpty else { return }
        let videoID = videoIds[currentIndex]
        print("▶️ 재생: \(videoID)")
        playerView.load(withVideoId: videoID, playerVars: ["playsinline": 1, "autoplay": 1])
    }
    
    @IBAction func prevButtonTapped(_ sender: UIButton) {
        guard !videoIds.isEmpty else { return }
        currentIndex = (currentIndex - 1 + videoIds.count) % videoIds.count
        loadCurrentVideo()
    }
    
    @IBAction func pauseButtonTapped(_ sender: UIButton) {
        isPlaying.toggle()
        if isPlaying {
            playerView.playVideo()
            pauseButton.setTitle("⏸", for: .normal)
        } else {
            playerView.pauseVideo()
            pauseButton.setTitle("▶️", for: .normal)
        }
    }
    
    @IBAction func nextButtonTapped(_ sender: UIButton) {
        guard !videoIds.isEmpty else { return }
        currentIndex = (currentIndex + 1) % videoIds.count
        loadCurrentVideo()
    }
    
    @IBAction func homeButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let homeVC = storyboard.instantiateViewController(withIdentifier: "HomeViewController") as? HomeViewController {
            homeVC.modalPresentationStyle = .fullScreen
            present(homeVC, animated: true, completion: nil)
        }
    }
    
}
