
//

import Foundation

class YouTubeSearchService {
    let apiKey: String

    init(apiKey: String) {
        self.apiKey = apiKey
    }

    func search(query: String, maxResults: Int = 5, completion: @escaping ([String]) -> Void) {
        let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let urlString = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=\(encodedQuery)&type=video&key=\(apiKey)&maxResults=\(maxResults)"

        guard let url = URL(string: urlString) else {
            print("잘못된 URL")
            completion([])
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil else {
                print("네트워크 오류: \(error?.localizedDescription ?? "알 수 없음")")
                completion([])
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let items = json["items"] as? [[String: Any]] {
                    let videoIds = items.compactMap { item -> String? in
                        guard let id = item["id"] as? [String: Any],
                              let videoId = id["videoId"] as? String else { return nil }
                        return videoId
                    }
                    completion(videoIds)
                } else {
                    print("JSON 구조 예상과 다름")
                    completion([])
                }
            } catch {
                print("JSON 파싱 실패: \(error)")
                completion([])
            }
        }.resume()
    }
}
