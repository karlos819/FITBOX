import UIKit
import FirebaseAuth

class SignupViewController: UIViewController {
    @IBOutlet weak var nicknameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var birthYearTextField: UITextField!
    @IBOutlet weak var birthMonthTextField: UITextField!
    @IBOutlet weak var birthDayTextField: UITextField!
    @IBOutlet weak var genderSegmentedControl: UISegmentedControl!
    @IBOutlet weak var addressTextField: UITextField!

    @IBAction func signUpButtonTapped(_ sender: UIButton) {
        // 입력값 가져오기
        let nickname = nicknameTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        let confirmPassword = confirmPasswordTextField.text ?? ""
        let birthYear = birthYearTextField.text ?? ""
        let birthMonth = birthMonthTextField.text ?? ""
        let birthDay = birthDayTextField.text ?? ""
        let genderIndex = genderSegmentedControl.selectedSegmentIndex
        _ = genderIndex == 0 ? "남" : "여"
        let address = addressTextField.text ?? ""

        // 간단한 유효성 검사
        if nickname.isEmpty || email.isEmpty || password.isEmpty || confirmPassword.isEmpty ||
            birthYear.isEmpty || birthMonth.isEmpty || birthDay.isEmpty || address.isEmpty {
            showAlert(message: "모든 항목을 입력해주세요.")
            return
        }
        if password != confirmPassword {
            showAlert(message: "비밀번호가 일치하지 않습니다.")
            return
        }

        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                   if let error = error {
                       self.showAlert(message: "회원가입 실패: \(error.localizedDescription)")
                       return
                   }

                   // ✅ 회원가입 성공 → 알림 후 로그인 화면으로 복귀
                   self.showAlert(message: "회원가입이 완료되었습니다!") {
                       self.dismiss(animated: true, completion: nil)
                   }
               }
           }

    func showAlert(message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "확인", style: .default, handler: { _ in
            completion?()
        }))
        present(alert, animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        nicknameTextField.placeholder = "닉네임을 입력하세요"
        emailTextField.placeholder = "이메일을 입력하세요"
        passwordTextField.placeholder = "비밀번호를 입력하세요"
        confirmPasswordTextField.placeholder = "비밀번호를 다시 입력하세요"
        birthYearTextField.placeholder = "출생년도(YYYY)"
        birthMonthTextField.placeholder = "월(MM)"
        birthDayTextField.placeholder = "일(DD)"
        addressTextField.placeholder = "주소를 입력하세요"
        
        
    }
}
