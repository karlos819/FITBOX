import UIKit
import MapKit

class HomeViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var startButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupMap()
    }

    func setupUI() {
        // '사용자 정보' 버튼으로 설정
        menuButton.setTitle("Menu", for: .normal)
        menuButton.setTitleColor(.systemBlue, for: .normal)
        menuButton.addTarget(self, action: #selector(goToUserInfo), for: .touchUpInside)

        // 시작 버튼 스타일
        startButton.setTitle("운동 시작", for: .normal)
        startButton.backgroundColor = .systemGreen
        startButton.setTitleColor(.white, for: .normal)
        startButton.layer.cornerRadius = startButton.frame.height / 2
    }

    func setupMap() {
        let center = CLLocationCoordinate2D(latitude: 37.5665, longitude: 126.9780) // 서울 중심
        let region = MKCoordinateRegion(center: center, latitudinalMeters: 1000, longitudinalMeters: 1000)
        mapView.setRegion(region, animated: false)
    }

    @objc func goToUserInfo() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let userVC = storyboard.instantiateViewController(withIdentifier: "UserViewController") as? UserViewController {
            userVC.modalPresentationStyle = .fullScreen
            present(userVC, animated: true, completion: nil)
        }
    }

    @IBAction func startButtonTapped(_ sender: UIButton) {
        print("운동 시작 버튼 클릭됨")

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let exerciseVC = storyboard.instantiateViewController(withIdentifier: "ExerciseViewController") as? ExerciseViewController {
            exerciseVC.modalPresentationStyle = .fullScreen
            present(exerciseVC, animated: true, completion: nil)
        }
    }
}

