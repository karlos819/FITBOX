import Foundation
import UIKit

class UserViewController: UIViewController {

    // 배경 뷰 (민트색)
    @IBOutlet weak var profileBackgroundView: UIView!
    @IBOutlet weak var calendarBackgroundView: UIView!
    @IBOutlet weak var helpBackgroundView: UIView!
    @IBOutlet weak var infoBackgroundView: UIView!

    // 버튼 (동작 연결용)
    @IBOutlet weak var profileButton: UIButton!
    @IBOutlet weak var calendarButton: UIButton!
    @IBOutlet weak var helpButton: UIButton!
    @IBOutlet weak var infoButton: UIButton!

    // ← 뒤로가기 버튼
    @IBOutlet weak var backButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackgroundViews()
        setupBackButton()
    }

    func setupBackgroundViews() {
        let views = [profileBackgroundView, calendarBackgroundView, helpBackgroundView, infoBackgroundView]
        views.forEach {
            $0?.backgroundColor = UIColor.systemMint
            $0?.layer.cornerRadius = 16
            $0?.clipsToBounds = true
        }
    }

    func setupBackButton() {
        backButton.setTitle("←", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)
    }

    @IBAction func backButtonTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    @IBAction func profileButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "ProfileViewController") as? ProfileViewController {
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true, completion: nil)
        }
    }

    @IBAction func calendarButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "CalendarViewController") as? CalendarViewController {
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true, completion: nil)
        }
    }

    @IBAction func helpButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "ExerciseInfoViewController") as? ExerciseInfoViewController {
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true, completion: nil)
        }
    }

    @IBAction func infoButtonTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let vc = storyboard.instantiateViewController(withIdentifier: "AppInfoViewController") as? AppInfoViewController {
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true, completion: nil)
        }
    }
}
