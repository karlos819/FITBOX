import UIKit

class ExerciseInfoViewController: UIViewController {

    // 뒤로가기 버튼
    @IBOutlet weak var backButton: UIButton!

    // 블록 1 (워밍업)
    @IBOutlet weak var blockView1: UIView!
    @IBOutlet weak var titleLabel1: UILabel!
    @IBOutlet weak var descriptionLabel1: UILabel!

    // 블록 2 (페이스 조절)
    @IBOutlet weak var blockView2: UIView!
    @IBOutlet weak var titleLabel2: UILabel!
    @IBOutlet weak var descriptionLabel2: UILabel!

    // 블록 3 (러닝화)
    @IBOutlet weak var blockView3: UIView!
    @IBOutlet weak var titleLabel3: UILabel!
    @IBOutlet weak var descriptionLabel3: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // ← 버튼 설정
        backButton.setTitle("←", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)

        // 각 블록 스타일 적용
        styleBlockView(blockView1)
        styleBlockView(blockView2)
        styleBlockView(blockView3)

        // 각 텍스트 설정
        titleLabel1.text = "워밍업은 필수입니다!"
        descriptionLabel1.text = """
달리기 전에 가벼운 스트레칭과 준비 운동을 해주세요.
부상을 줄이고 운동 효과를 높일 수 있어요.
"""

        titleLabel2.text = "페이스 조절이 중요해요!"
        descriptionLabel2.text = """
처음부터 무리하지 말고,
자신의 체력에 맞는 속도로 달려야 오래 달릴 수 있어요.
"""

        titleLabel3.text = "신발이 생명입니다!"
        descriptionLabel3.text = """
전용 러닝화를 꼭 착용하세요.
충격을 줄여주고 무릎과 발목을 보호해줍니다.
"""
    }

    // 홈으로 돌아가기
    @IBAction func backToHomeTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    // 블록뷰 스타일 지정
    func styleBlockView(_ view: UIView) {
        view.backgroundColor = UIColor.systemGray6
        view.layer.cornerRadius = 12
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.05
        view.layer.shadowOffset = CGSize(width: 0, height: 2)
        view.layer.shadowRadius = 4
    }
}
