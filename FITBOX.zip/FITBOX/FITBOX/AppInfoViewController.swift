import UIKit

class AppInfoViewController: UIViewController {

    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var appNameLabel: UILabel!
    @IBOutlet weak var developerLabel: UILabel!
    @IBOutlet weak var versionLabel: UILabel!
    @IBOutlet weak var logoImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // ← 버튼 설정
        backButton.setTitle("←", for: .normal)
        backButton.setTitleColor(.systemBlue, for: .normal)

        // 이미지 설정
        logoImageView.image = UIImage(named: "fitbox_logo")
        logoImageView.contentMode = .scaleAspectFit

        // 앱 정보 설정
        appNameLabel.text = "앱 이름: FITBOX"
        developerLabel.text = "개발자: 김문성"
        versionLabel.text = "버전: " + (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "정보 없음")
    }

    @IBAction func backToHomeTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
}
